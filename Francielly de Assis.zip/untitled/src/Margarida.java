class Margarida extends Flor {
    private int altura;

    public Margarida(String cor, int altura) {
        super("Margarida", cor);  // Chama o construtor da classe mãe (Flor)
        this.altura = altura;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println("Flor: " + getNome() + ", Cor: " + getCor() + ", Altura: " + altura + " cm");
    }

    @Override
    public String toString() {
        return "Margarida " + getCor() + " com altura de " + altura + " cm";
    }
}
