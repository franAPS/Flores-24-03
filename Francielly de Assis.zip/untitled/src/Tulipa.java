class Tulipa extends Flor {
    private String fragrancia;

    public Tulipa(String cor, String fragrancia) {
        super("Tulipa", cor);  // Chama o construtor da classe mãe (Flor)
        this.fragrancia = fragrancia;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println("Flor: " + getNome() + ", Cor: " + getCor() + ", Fragrância: " + fragrancia);
    }

    @Override
    public String toString() {
        return "Tulipa " + getCor() + " com fragrância " + fragrancia;
    }
}