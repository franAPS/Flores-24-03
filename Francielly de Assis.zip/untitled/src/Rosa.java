class Rosa extends Flor {
    private String tipoPetala;

    public Rosa(String cor, String tipoPetala) {
        super("Rosa", cor);  // Chama o construtor da classe mãe (Flor)
        this.tipoPetala = tipoPetala;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println("Flor: " + getNome() + ", Cor: " + getCor() + ", Tipo de pétala: " + tipoPetala);
    }

    @Override
    public String toString() {
        return "Rosa " + getCor() + " com pétalas do tipo " + tipoPetala;
    }
}